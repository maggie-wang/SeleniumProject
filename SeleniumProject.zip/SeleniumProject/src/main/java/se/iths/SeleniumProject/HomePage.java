package se.iths.SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

	private static WebElement element = null;
	
	public static String pageTitle(WebDriver driver){
		return driver.getTitle();
	}
	public static WebElement search_Input(WebDriver driver){
		element = driver.findElement(By.className("search"));
		return element;
	}
	public static WebElement account_Btn(WebDriver driver){
		element = driver.findElement(By.id("account"));
		return element;
	}
	public static WebElement accountOut_Btn(WebDriver driver){
		element = driver.findElement(By.id("account_logout"));
		return element;
	}	
	public static WebElement buyNow_Btn(WebDriver driver){
		element = driver.findElement(By.className("buynow"));
		return element;
	}	
	public static WebElement SP_itemCounter_Link(WebDriver driver){
		element = driver.findElement(By.className("count"));
		return element;
	}
	
	public static WebElement SP_checkOut_Icon(WebDriver driver){
		element = driver.findElement(By.className("cart_icon"));
		return element;
	}

}
