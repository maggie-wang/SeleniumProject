package iths.project3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CheckOut_YouCart_Page {
	private static WebElement element = null;
	
	public static WebElement CheckOut_Cart_Table(WebDriver driver){
		element = driver.findElement(By.className("checkout_cart"));
		return element;
	}
	
	public static WebElement Product_Detail_Info(WebDriver driver, int row, int col){
		WebElement ShoppingCartTable = driver.findElement(By.className("checkout_cart"));
		List<WebElement> tableRows = ShoppingCartTable.findElements(By.tagName("tr"));
		List<WebElement> rowElements = tableRows.get(row).findElements(By.tagName("td"));
		element = rowElements.get(col);
		return element;
	}
	
	public static WebElement Continue_Btn(WebDriver driver){
		element = driver.findElement(By.className("step2"));
		return element;
	}
	
}


