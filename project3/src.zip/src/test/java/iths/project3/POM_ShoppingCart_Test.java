package iths.project3;

import static org.junit.Assert.assertEquals;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/*
 * Author: YU WANG
 * Date: 2016-04-07
 * 
 * White-box testing: test UI component 
 * Branch testing. (test cases: buyOneItemCheckOutWithOutLogin and buyOneItemContinueWithOutoginIn)
 * Use case testing
 * Boundary testing --- checkOutWithEmptyShoppingCartWiutoginInCheckCounter
 * Test cases cover different senarios/flow.
 * Most test cases here are assumed that user is not logged in the system.
 * The only test cases that need login info is when test the whole purchase process.
 * 
 */
public class POM_ShoppingCart_Test {

	private WebDriver driver;
	String userName = "cat";
	String pwd = "be123456";
	String itemName;
	double itemPrice;
	String popUpCheckOutBtnLabel = "go_to_checkout";
	String popUpContinueShoppingBtnLabel = "continue_shopping";
	
    int shoppingCart_productInfo_Row = 1;
    int shoppingCart_nameCol = 1;
    int shoppingCart_priceCol = 3;
    int shoppingCart_totalPriceCol = 4;
	
	@Before
	public void setup(){
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://store.demoqa.com");
		driver.manage().window().maximize();

	}
	
	@After
	public void testDown(){
		driver.quit();
	}
	
	// Buy one item and continue shopping---without log in. 
    @Test
    public void buyOneItemContinueWithOutoginIn() throws InterruptedException{
    	clickBuyNow_btn();
    	addOneItemInShoppingCart();
    	AlertPopupPage.popup_Btn(popUpContinueShoppingBtnLabel, driver).click();
    	Thread.sleep(2000);	    	
    } 
    
	// //Buy one item and continue shopping---without log in. 
    @Test
    public void buyOneItemForTenTimesContinueWithOutLoginIn() throws InterruptedException{
    	
    	int originItemCounter = Integer.parseInt(HomePage.SP_itemCounter_Link(driver).getText());
    	clickBuyNow_btn();
    	
    	for(int i = 0; i < 10; i++){
    		addOneItemInShoppingCart();
    		AlertPopupPage.popup_Btn(popUpContinueShoppingBtnLabel, driver).click(); 
    		Thread.sleep(5000);
    	}
    	int changedItemCounter = Integer.parseInt(HomePage.SP_itemCounter_Link(driver).getText());
    	assertEquals(10, (changedItemCounter - originItemCounter));
    	
    }    
	
   // test counter of shopping cart  ---without log in. 
   @Test
   public void buyOneItemCheckOutWithoutLoginInCheckCounter() throws InterruptedException{
   	
   	int originItemCounter = Integer.parseInt(HomePage.SP_itemCounter_Link(driver).getText());
   	clickBuyNow_btn();
   	addOneItemInShoppingCart();
   	AlertPopupPage.popup_Btn(popUpCheckOutBtnLabel, driver).click(); 
   	Thread.sleep(1000);
   	int changedItemCounter = Integer.parseInt(HomePage.SP_itemCounter_Link(driver).getText());
   	assertEquals(1, (changedItemCounter - originItemCounter));
   }
   
  // test counter of shopping cart  ---without log in. 
  @Test
  public void checkOutWithEmptyShoppingCartWiutoginInCheckCounter() throws InterruptedException{
  	
  	HomePage.SP_checkOut_Icon(driver).click();
  	
  	Thread.sleep(1000);
  	
  	String empty = CheckOut_Info_Final_Page.pageEmptyMsg(driver).getText();
  	String emptyMsg = "Oops, there is nothing in your cart.";
  	assertEquals(emptyMsg, empty);
  }
   
   //test buy one item and check out without pre-logged in   
   @Test
   public void buyOneItemCheckOutWithOutLogin() throws InterruptedException{
	   
   	clickBuyNow_btn();
   	addOneItemInShoppingCart();
   	AlertPopupPage.popup_Btn(popUpCheckOutBtnLabel, driver).click(); 
   	Thread.sleep(1000);
   	
   	int itemCounter = Integer.parseInt(HomePage.SP_itemCounter_Link(driver).getText());
   	//String itemName = ProductCategoryPage.item_Name(driver).getText();
   	
   	String checkOutProductName =CheckOut_YouCart_Page
   			.Product_Detail_Info(driver, shoppingCart_productInfo_Row, shoppingCart_nameCol)
   			.getText();
   	double productPrice = Double.parseDouble
   			(CheckOut_YouCart_Page.Product_Detail_Info(driver, shoppingCart_productInfo_Row, shoppingCart_priceCol)
   					.getText().replace("$", ""));
    
    double totalPrice = Double.parseDouble
   			(CheckOut_YouCart_Page.Product_Detail_Info(driver, shoppingCart_productInfo_Row, shoppingCart_totalPriceCol)
   					.getText().replace("$", ""));
    CheckOut_YouCart_Page.Continue_Btn(driver).click();
    Thread.sleep(1000);
       
    CheckOut_Info_Page.UserName_Input(driver).sendKeys(userName);
    CheckOut_Info_Page.Password_Input(driver).sendKeys(pwd);
    CheckOut_Info_Page.Login_Btn(driver).submit();
    
    Thread.sleep(3000);
    CheckOut_Info_Page.Purchase_Btn(driver).submit();
    Thread.sleep(3000);
    String checkOutFinalPageTitle = "Transaction Results | ONLINE STORE";
    String prodName = "Magic Mouse"; 
    double prodPrice = 150.00;
    double prodTotalPrice = 150.00;
    int prodCounter = 1;
    assertEquals(prodName, checkOutProductName);
    assertEquals(prodPrice, productPrice,0.001);
    assertEquals(prodTotalPrice, totalPrice,0.001);
    assertEquals(prodCounter, itemCounter);
    assertEquals(driver.getTitle(), checkOutFinalPageTitle);
	
   }
   
   
    public void clickBuyNow_btn(){
    	HomePage.buyNow_Btn(driver).click();
    }
    
    //add one item in the shoppingcart
    public void addOneItemInShoppingCart(){
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	Slide_Item_Page.wpsc_Buy_Btn(driver).click();
    }
    


}
